﻿Write-EventLog –LogName Application –Source "ASPEX" –EntryType Information –EventID 1 –Message "Starting AlertSourceFileCReationScript"
$api = new-object -comObject 'MOM.ScriptAPI'
$api.LogScriptEvent('CreateAlertSourceFile.ps1',20,4,$computerName)
$bag = $api.CreatePropertyBag()
$strText = ""

if ( (Get-PSSnapin -Name VMware.VimAutomation.Core -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin VMware.VimAutomation.Core
}

Write-EventLog –LogName Application –Source "ASPEX" –EntryType Information –EventID 1 –Message "Running AlertSourceFileCReationScript"
#Write-Host ("Getting the alarms from {0} vCenters." -f $vCenters.Length)
$vc = Connect-VIServer localhost
Write-EventLog –LogName Application –Source "ASPEX" –EntryType Information –EventID 1 –Message "Connected to Local Vi Server"
$rootFolder = Get-Folder -Server $vc "Datacenters"
foreach ($ta in $rootFolder.ExtensionData.TriggeredAlarmState) {
		$strText = $strText + (Get-View -Server $vc $ta.Entity).Name + "," + (Get-View -Server $vc $ta.Alarm).Info.Name + "," + $ta.OverallStatus + "," + $ta.Time + "," + $ta.Acknowledged + "," + $ta.AcknowledgedByUser + "," + $ta.AcknowledgedTime + "`r`n"
	}
Write-EventLog –LogName Application –Source "ASPEX" –EntryType Information –EventID 1 –Message "Alerts placed in Var"
Disconnect-VIServer localhost -Confirm:$false
Write-EventLog –LogName Application –Source "ASPEX" –EntryType Information –EventID 1 –Message "Disconnect Session"
$strAlarms = "EntityName;AlarmName;OverallStatus;TimeTriggered;Acknowledged;AcknowledgedByUser;AcknowledgedTime" + "`r`n" + $strText

Write-EventLog –LogName Application –Source "ASPEX" –EntryType Information –EventID 1 –Message $strText
if($strAlarms -ne ''){
	out-file -filepath "c:\Program Files\Microsoft Monitoring Agent\vmWareAlertSource.txt" -inputobject $strAlarms -Encoding "default"
	$bag.AddValue('AlertSourceFileStatus','OK')}
	else{
	$bag.AddValue('AlertSourceFileStatus','NOK')}

#$api.Return($bag)
$bag
Write-EventLog –LogName Application –Source "ASPEX" –EntryType Information –EventID 1 –Message "Finished AlertSourceFileCReationScript"