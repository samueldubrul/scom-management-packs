﻿param($sourceId,$managedEntityId,$computerName)

#$LogFile = "c:\temp\discovery.log"
#Add-content $LogFile -value "Start Script for $computerName" 

Add-PSSnapin -Name "VMware.VimAutomation.Core"
$api = new-object -comObject 'MOM.ScriptAPI'
$discoveryData = $api.CreateDiscoveryData(0, $SourceId, $ManagedEntityId)



Try
{
Connect-VIServer -Server $computerName
#Add-content $LogFile -value "Connect-VIServer -Server $computerName" 

$VmHosts = get-vmhost

Foreach($VmHost in $VmHosts){
	#Add-content $LogFile -value "$VmHost.Name"
	$instance = $discoveryData.CreateClassInstance("$MPElement[Name='Vmware.VmHost']$")
	#Add-content $LogFile -value "$instance"
	$instance.AddProperty("$MPElement[Name='Windows!Microsoft.Windows.Computer']/PrincipalName$", $computerName)
	$Instance.AddProperty("$MPElement[Name='Vmware.VmHost']/EsxHostName$", $VmHost.Name)
	$Instance.AddProperty("$MPElement[Name='Vmware.VmHost']/EsxVersion$", $VmHost.Version)
	$discoveryData.AddInstance($instance)
	#Add-content $LogFile -value $discoveryData.AddInstance($instance)
	}
}
Catch
{
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
	$Message = $_.Exception.Message, $_.Exception.ItemName
	#Add-content $LogFile -value $ErrorMessage



}
#Add-content $LogFile -value "Return DiscoveryData"
#Add-content $LogFile -value  $api.Return($discoveryData)
#$api.Return($discoveryData)
$discoveryData