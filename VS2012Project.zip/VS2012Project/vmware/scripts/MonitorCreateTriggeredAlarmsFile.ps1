﻿param ([String[]]$vCenters)
$api = new-object -comObject 'MOM.ScriptAPI'
$bag = $api.CreatePropertyBag()


Add-PSSnapin -Name "VMware.VimAutomation.Core"
 $global:strText = ""
Function Get-TriggeredAlarms {
	param (
		$vCenter = $(throw "A vCenter must be specified."),
		[System.Management.Automation.PSCredential]$credential
	)
 
	#if ($credential) {
	#	$vc = Connect-VIServer $vCenter -Credential $credential
	#}
	#else {
		$vc = Connect-VIServer $vCenter
	#}
 
	if (!$vc) {
		Write-Host "Failure connecting to the vCenter $vCenter"
		exit
	}
	$rootFolder = Get-Folder -Server $vc "Datacenters"
 
	foreach ($ta in $rootFolder.ExtensionData.TriggeredAlarmState) {
	$global:strText = $global:strText + (Get-View -Server $vc $ta.Entity).Name + "," + (Get-View -Server $vc $ta.Alarm).Info.Name + "," + $ta.OverallStatus + "," + $ta.Time + "," + $ta.Acknowledged + "," + $ta.AcknowledgedByUser + "," + $ta.AcknowledgedTime + "`r`n"
	}
	Disconnect-VIServer $vCenter -Confirm:$false
}
 
Write-Host ("Getting the alarms from {0} vCenters." -f $vCenters.Length)
 

foreach ($vCenter in $vCenters) {
#	Write-Host "Getting alarms from $vCenter."
#	Write-Host "EntityName;AlarmName;OverallStatus;TimeTriggered;Acknowledged;AcknowledgedByUser;AcknowledgedTime"
	Get-TriggeredAlarms $vCenter
	$strAlarms = "EntityName;AlarmName;OverallStatus;TimeTriggered;Acknowledged;AcknowledgedByUser;AcknowledgedTime" + "`r`n" + $global:strText
	if($strAlarms){
	out-file -filepath "c:\Program Files\Microsoft Monitoring Agent\vmWareAlertSource.txt" -inputobject $strAlarms -Encoding "default"
	$bag.AddValue('AlertSourceFileStatus','OK')}
	else{$bag.AddValue('AlertSourceFileStatus','NOK')}
	
$bag

}